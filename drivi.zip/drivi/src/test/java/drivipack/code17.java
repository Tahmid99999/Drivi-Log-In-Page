package drivipack;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import dev.failsafe.internal.util.Assert;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chromium.ChromiumDriver;



public class code17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//webdriver intialiazation
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		//browserOn
		 driver.get("https://drivi.cloud/login");
		 driver.manage().window().maximize();
		
		//Login
		 
		 WebElement emailfield = driver.findElement(By.id("drivi_login"));
		 emailfield.sendKeys("drividevtest@mailinator.com");
		 
		 //password 
		 WebElement passwordfield= driver.findElement(By.id("drivi_pass"));
		 passwordfield.sendKeys(" P@$$w0rd12");
		 //Login Button
		 WebElement loginButton = driver.findElement(By.cssSelector("button.btn"));
	     loginButton.click();
		 
	     try {
	            Thread.sleep(5000);  // Wait for 5 seconds (replace with explicit wait if needed)
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    //Assert.assertTrue("User logged in successfully? ", driver.getTitle().trim().equals("expected title");
		  
		  System.out.println("Page title after login: " + driver.getTitle());
		  
		  driver.quit();
		 
		
		
		
		
		

	}

}
